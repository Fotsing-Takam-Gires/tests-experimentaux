#!/usr/bin/python3
import pandas as pd
import glob
import os
import matplotlib.pyplot as plt
import numpy as np

chemin = "/home/pi/Desktop/Essaie a Cr variant 3 avec changement de position capteur 18V/Cr = 0.1 V=22"

pattern = os.path.join(chemin, "resume_puissances_rendements*pic.csv")

toutes_les_colonnes = {}  
noms_des_fichiers = []    
for fichier in sorted(glob.glob(pattern)):
    df = pd.read_csv(fichier)
    noms_des_fichiers.append(fichier)
    for colonne in df.columns:
        if colonne not in toutes_les_colonnes:
            toutes_les_colonnes[colonne] = []
        toutes_les_colonnes[colonne].append(df[colonne].values[0])

vitesse_values = toutes_les_colonnes.get("Vitesse", [])
Courant0_values = toutes_les_colonnes.get("Courant moyen0", [])
Courant1_values = toutes_les_colonnes.get("Courant moyen1", [])
Couple_values = toutes_les_colonnes.get("Couple moyen (Nm)", [])
Pmeca_values = toutes_les_colonnes.get("Puissance mécanique moyenne (W)", [])
Pelec0_values = toutes_les_colonnes.get("Puissance électrique M0 moyenne (W)", [])
Pelec1_values = toutes_les_colonnes.get("Puissance électrique M1 moyenne (W)", [])
R1_values = toutes_les_colonnes.get("Rendement 1 (%) (meca/elec0)", [])
R2_values = toutes_les_colonnes.get("Rendement 2 (%) (elec1/meca)", [])
Rglob_values = toutes_les_colonnes.get("Rendement global (%) (elec1/elec0)", [])

print(len(vitesse_values))

# Tracé du Couple en fonction du Courant0
indices_trie_i = sorted(range(len(Courant0_values)), key=lambda i: Courant0_values[i])
courant0_sorted = [Courant0_values[i] for i in indices_trie_i]
couple_sorted_0 = [Couple_values[i] for i in indices_trie_i]

# Régression linéaire : Couple = a * I0 + b
coeffs0 = np.polyfit(courant0_sorted, couple_sorted_0, deg=1)
poly0 = np.poly1d(coeffs0)
regression_line0 = poly0(courant0_sorted)

plt.figure()
plt.plot(courant0_sorted, couple_sorted_0, label="Couple mesuré")
plt.plot(courant0_sorted, regression_line0, '--r', label=f"Régression : C = {coeffs0[0]:.2f}·I + {coeffs0[1]:.2f}  Avec Kr = {1.4142135*coeffs0[0]:.2f}")
plt.xlabel("Courant moyen0 (A)")
plt.ylabel("Couple moyen (Nm)")
plt.title("Couple = f(Courant0)")
plt.legend()
plt.grid(True)

# Tracé du Couple en fonction du Courant1
indices_trie_i = sorted(range(len(Courant1_values)), key=lambda i: Courant1_values[i])
courant1_sorted = [Courant1_values[i] for i in indices_trie_i]
couple_sorted_1 = [Couple_values[i] for i in indices_trie_i]

# Régression linéaire : Couple = a * I1 + b
coeffs1 = np.polyfit(courant1_sorted, couple_sorted_1, deg=1)
poly1 = np.poly1d(coeffs1)
regression_line1 = poly1(courant1_sorted)

plt.figure()
plt.plot(courant1_sorted, couple_sorted_1, label="Couple mesuré")
plt.plot(courant1_sorted, regression_line1, '--g', label=f"Régression : C = {coeffs1[0]:.2f}·I + {coeffs1[1]:.2f}  Avec Kr = {-1.4142135*coeffs1[0]:.2f}")
plt.xlabel("Courant moyen1 (A)")
plt.ylabel("Couple moyen (Nm)")
plt.title("Couple = f(Courant1)")
plt.legend()
plt.grid(True)

# Tracé des Puissances en fonction du Couple
indices_trie_c = sorted(range(len(Couple_values)), key=lambda i: Couple_values[i])
plt.figure()
plt.plot([Couple_values[i] for i in indices_trie_c], [Pelec0_values[i] for i in indices_trie_c], label="Pelec0 = f1(C)")
plt.plot([Couple_values[i] for i in indices_trie_c], [Pmeca_values[i] for i in indices_trie_c], label="Pmeca = f2(C)")
plt.plot([Couple_values[i] for i in indices_trie_c], [Pelec1_values[i] for i in indices_trie_c], label="Pelec1 = f3(C)")
plt.xlabel("Couple moyen (Nm)")
plt.ylabel("Puissance (W)")
plt.legend()
plt.grid(True)


# Tracé des Puissances en fonction de la vitesse
indices_trie_v = sorted(range(len(vitesse_values)), key=lambda i: Couple_values[i])
plt.figure()
plt.plot([vitesse_values[i] for i in indices_trie_v], [Pelec0_values[i] for i in indices_trie_v], label="Pelec0 = f4(V)")
plt.plot([vitesse_values[i] for i in indices_trie_v], [Pmeca_values[i] for i in indices_trie_v], label="Pmeca = f5(V)")
plt.plot([vitesse_values[i] for i in indices_trie_v], [Pelec1_values[i] for i in indices_trie_v], label="Pelec1 = f6(V)")
plt.xlabel("Rad/s")
plt.ylabel("Puissance (W)")
plt.legend()
plt.grid(True)

# Tracé des Rendements en fonction du Couple
plt.figure()
plt.plot([Couple_values[i] for i in indices_trie_c], [R1_values[i] for i in indices_trie_c], label="R1 = f7(C)")
plt.plot([Couple_values[i] for i in indices_trie_c], [R2_values[i] for i in indices_trie_c], label="R2 = f8(C)")
#plt.plot([Couple_values[i] for i in indices_trie_c], [Rglob_values[i] for i in indices_trie_c], label="Rglobal = f9(C)")
plt.xlabel("Couple moyen (Nm)")
plt.ylabel("Rendement (%)")
plt.legend()
plt.grid(True)

# Tracé des Rendements en fonction de la vitesse
plt.figure()
plt.plot([vitesse_values[i] for i in indices_trie_v], [R1_values[i] for i in indices_trie_v], label="R1 = f10(V)")
plt.plot([vitesse_values[i] for i in indices_trie_v], [R2_values[i] for i in indices_trie_v], label="R2 = f11(V)")
#plt.plot([vitesse_values[i] for i in indices_trie_v], [Rglob_values[i] for i in indices_trie_v], label="Rglobal = f12(V)")
plt.xlabel("Vitesse moyenne (rad/s)")
plt.ylabel("Rendement (%)")
plt.legend()
plt.grid(True)


# Tracé du Couple en fonction de la vitesse
indices_trie_i = sorted(range(len(Courant0_values)), key=lambda i: Courant0_values[i])
indices_trie_v = sorted(range(len(vitesse_values)), key=lambda i: Couple_values[i])
plt.figure()
plt.plot([vitesse_values[i] for i in indices_trie_v], [Couple_values[i] for i in indices_trie_i], label="C = f13(V)")
plt.xlabel("Vitesse (rad/s)")
plt.ylabel("Couple moyen (Nm)")
plt.legend()
plt.grid(True)


# Régression linéaire : Pelec1 = a * Pmeca + b
Pmeca_sorted = [Pmeca_values[i] for i in indices_trie_v]
Pelec1_sorted = [Pelec1_values[i] for i in indices_trie_v]
coeffs_power = np.polyfit(Pmeca_sorted, Pelec1_sorted, deg=1)
poly_power = np.poly1d(coeffs_power)
regression_line_power = poly_power(Pmeca_sorted)
plt.figure()
plt.plot(Pmeca_sorted, Pelec1_sorted, label="Pelec1 = f14(Pmeca)")
plt.plot(Pmeca_sorted, regression_line_power, '--r',
label=f"Régression : Pelec1 = {coeffs_power[0]:.2f}·Pmeca + {coeffs_power[1]:.2f}")
plt.xlabel("Puissance mécanique (W)")
plt.ylabel("Puissance électrique M1 (W)")
plt.title("Régression linéaire Pelec1 = f(Pmeca)")
plt.legend()
plt.grid(True)


plt.show()
