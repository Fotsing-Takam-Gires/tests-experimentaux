#!/usr/bin/python3
import time
import serial
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from math import pi
from odri_spi_rpi import *

# ============ PARAMÈTRES ===============
dt = 0.001
N = 10000
T = N * dt
r = 1 / 6.2
R = 0.53
qi = 0
qf = pi*13
D = qf - qi
Ke = 0.3
a = 2 * D / T**2
g = 9.81
d = 5.85 * 0.01
Ta = 2
Td = 2
Tc = T - Ta - Td
t1 = 3
t2 = 7
Vmax = abs(a / T)

# ============ INITIALISATION ===========
try:
    ser = serial.Serial('/dev/ttyACM0', 115200, timeout=1)
except serial.SerialException as e:
    print(f"Erreur port série : {e}")
    exit(1)

def sync_serial():
    print("Recherche synchronisation série...")
    check = 0
    while True:
        if ser.read(1).hex() == '31':
            ser.read(5)
            if ser.read(1).hex() == '31':
                check += 1
                if check == 5:
                    print("Synchronisation série trouvée.")
                    return
            else:
                check = 0

sync_serial()

ud = SPIuDriver(waitForInit=True)
ud.timeout = 50

def moving_average(data, window_size=1000):
    return np.convolve(data, np.ones(window_size)/window_size, mode='same')
   
def vitesse_trapezoidale(t, ta, Tc, Td, Vmax):
    if t < Ta:
        return Vmax * t / Ta
    elif t < Ta + Tc:
        return Vmax
    elif t < Ta + Tc + Td:
        return Vmax * (1 - (t - Ta - Tc) / Td)
    else:
        return 0
        
def position_trapezoidale(t, qi, qf, Ta, Tc, Td):
    D = qf - qi  # Amplitude du mouvement
    T = Ta + Tc + Td
    Vmax = D / (0.5 * Ta + Tc + 0.5 * Td)  # Vmax calculé automatiquement

    if t < 0:
        return qi
    elif t < Ta:
        return qi + 0.5 * Vmax * t**2 / Ta
    elif t < Ta + Tc:
        return qi + 0.5 * Vmax * Ta + Vmax * (t - Ta)
    elif t < T:
        t_dec = t - Ta - Tc
        return qi + 0.5 * Vmax * Ta + Vmax * Tc + Vmax * t_dec - 0.5 * Vmax * t_dec**2 / Td
    else:
        return qf


# ============ LOGS =============
t_list = []
log_data = []
pos0, vel0, refpos0_list, refvelo0_list, cur0, tension0_calcule_list = [], [], [], [], [], []
pos1, vel1, refpos1_list, refvelo1_list, cur1, tension1_calcule_list = [], [], [], [], [], []
couple_mesure = []

# ============ BOUCLE PRINCIPALE ============
t = time.perf_counter()
for i in range(N):
    ud.transfer()
    t += dt
    while time.perf_counter() - t < dt:
        time.sleep(0.005)

    t_s = i * dt
   
    #qref = (qi + D*(10*((t_s/T)**3) - 15*((t_s/T)**4) + 6*((t_s/T)**5))) 
    
    qref = position_trapezoidale(t_s, qi, qf, Ta, Tc, Td)
    vref = vitesse_trapezoidale(t_s, Ta, Tc, Td, Vmax) 
   
    ud.refPosition0 = qref / r
    ud.refVelocity0 = vref / r
    ud.kp0 = 1
    ud.kd0 = 0.1
    ud.refCurrent0 = 0.

    ud.refPosition1 = 0 * qref
    ud.refVelocity1 = 0 * (pi/10)
    ud.kp1 = 0.
    ud.kd1 = 0.1
    ud.refCurrent1 = 0.

    try:
        ser.read(2)
        force_bytes = ser.read(3)
        force_val = int.from_bytes(force_bytes, byteorder='big')
        sign = (force_val & 0x800000) >> 23
        cal_force = (force_val - (1 << 24) if sign == 1 else force_val)
        #cal_force = (-(cal_force*(1.5 / 10500) + (1.5 / 10500) * 274000) * g * d * 0.33 / 0.44)
        cal_force = (-(cal_force*(1.5 / 10500) + (1.5 / 10500) * 274000) * g * d)
    except:
        cal_force = None

    ser.read(7)
   

    # Puissance électrique
    puiss_elec0 = ud.voltage0* ud.current0 * 3 / 2
    puiss_elec1 = ud.voltage1 * ud.current1 * 3 / 2

    t_list.append(t_s)
    pos0.append(ud.position0 * r)
    vel0.append((ud.velocity0 * r))
    refpos0_list.append(ud.refPosition0)
    refvelo0_list.append(ud.refVelocity0)
    cur0.append((ud.current0))
    tension0_calcule_list.append((ud.voltage0))
    tension1_calcule_list.append((ud.voltage1))
    pos1.append(ud.position1 * r)
    vel1.append((ud.velocity1 * r))
    refpos1_list.append(ud.refPosition1)
    refvelo1_list.append(ud.refVelocity1)
    cur1.append((-ud.current1))
    couple_mesure.append((cal_force))
    
    puiss_meca = (cal_force * vel0[-1] if cal_force is not None else None)
    
    log_data.append({
    "t": t_s,
    "refpos0": refpos0_list[-1],
    "pos0": pos0[-1],
    "refpos1": refpos1_list[-1],
    "pos1": pos1[-1],
    "refvel0": refvelo0_list[-1],
    "vel0": vel0[-1],
    "refvel1": refvelo1_list[-1],
    "vel1": vel1[-1],
    "current0": cur0[-1],
    "current1": cur1[-1],
    "tension0_calcule": ud.voltage0,
    "tension1_calcule": ud.voltage1,
    "couple_capteur": cal_force,
    "puissance_elec0": puiss_elec0,
    "puissance_meca": puiss_meca,
    "puissance_elec1": puiss_elec1
    })


    print(f"[{t_s:.3f}s] M0: {pos0[-1]:.2f} rad | M1: {pos1[-1]:.2f} rad | Couple: {cal_force:.2f} Nm")
   
t_array = np.array(t_list)
mask_rp = (t_array >= t1) & (t_array <= t2)




ud.stop()

# ============ ANALYSE ============
pos0_rp = np.array(pos0)[mask_rp]
refpos0_list_rp = np.array(refpos0_list)[mask_rp]
refvelo0_list_rp = np.array(refvelo0_list)[mask_rp]
cur0_rp = np.array(cur0)[mask_rp]
tension0_calcule_rp = np.array(tension0_calcule_list)[mask_rp]
tension1_calcule_rp = np.array(tension1_calcule_list)[mask_rp]
pos1_rp = np.array(pos1)[mask_rp]
vel0_rp = np.array(vel0)[mask_rp]
vel1_rp = np.array(vel1)[mask_rp]
refpos1_list_rp = np.array(refpos1_list)[mask_rp]
refvelo1_list_rp = np.array(refvelo1_list)[mask_rp]
cur1_rp = np.array(cur1)[mask_rp]
couple_mesure_rp = np.array(couple_mesure)[mask_rp]
t_array = np.array(t_list)
t_array_rp = t_array[mask_rp]

puiss_elec0_rp = (tension0_calcule_rp * cur0_rp) * 3 / 2
puiss_elec1_rp = (tension1_calcule_rp * cur1_rp) * 3 / 2
puiss_mec_rp = (couple_mesure_rp * vel0_rp)

rendement0_rp = (100 * puiss_mec_rp / puiss_elec0_rp)
rendement1_rp = (100 * puiss_elec1_rp / puiss_mec_rp)
rendement_global_rp = (100 * puiss_elec1_rp / puiss_elec0_rp)


# Moyennes
puissmecmoy = np.mean(puiss_mec_rp)
puisselec0 = np.mean(puiss_elec0_rp)
puisselec1 = np.mean(puiss_elec1_rp)

#r0 = np.mean(rendement0_rp)
#r1 = np.mean(rendement1_rp)
#r_g = np.mean(rendement_global_rp)

r0 = 100 * puissmecmoy / puisselec0
r1 = 100 * puisselec1 / puissmecmoy
r_g = 100 * puisselec1 / puisselec0

vitesse = np.mean(vel0_rp)
couple_moyen = np.mean(couple_mesure_rp)
courant_moyen0_rp = np.mean(cur0_rp)
courant_moyen1_rp = np.mean(cur1_rp)

print(f"Puissance électrique 0 = {puisselec0} W , Puissance mécanique = {puissmecmoy} W et Puissance électrique 1 = {puisselec1} W")
print(f"Rendement 0 = {r0} %, Rendement 1 = {r1} % et Rendement global = {r_g} %")


summary_data = {
    "Intervalle t1-t2 (s)": [f"{t1}-{t2}"],
    "Vitesse" : [vitesse],
    "Courant moyen0" : [courant_moyen0_rp],
    "Courant moyen1" : [courant_moyen1_rp],
    "Couple moyen (Nm)": [couple_moyen],
    "Puissance mécanique moyenne (W)": [puissmecmoy],
    "Puissance électrique M0 moyenne (W)": [puisselec0],
    "Puissance électrique M1 moyenne (W)": [puisselec1],
    "Rendement 1 (%) (meca/elec0)": [r0],
    "Rendement 2 (%) (elec1/meca)": [r1],
    "Rendement global (%) (elec1/elec0)": [r_g]
}

pd.DataFrame(log_data).to_csv("Resumé temporelle.csv", index=False)
pd.DataFrame(summary_data).to_csv("resume_puissances_rendements.csv", index=False)

    # Obtenir les indices qui trient liste1
indices_trie = sorted(range(len(cur0_rp)), key=lambda i: cur0_rp[i])

# Trier liste1 et réorganiser liste2 en fonction
liste1_triee = [cur0_rp[i] for i in indices_trie]
liste2_reorganisee = [couple_mesure_rp[i] for i in indices_trie]

# ============ TRACÉS ============

plt.figure()
plt.plot(t_array_rp, pos0_rp, label="Position M0")
#plt.plot(t_array_rp, refpos0_list_rp, '--', label="Réf Position M0")
plt.plot(t_array_rp, pos1_rp, label="Position M1")
#plt.plot(t_array_rp, refpos1_list_rp, '--', label="Réf Position M1")
plt.title("Positions")
plt.xlabel("Temps (s)")
plt.ylabel("Position angulaire (rad)")
plt.legend()
plt.grid()

plt.figure()
plt.plot(t_array_rp, vel0_rp, label="Vitesse M0")
#plt.plot(t_array_rp, refvelo0_list_rp, '--', label="Réf Vitesse M0")
plt.plot(t_array_rp, vel1_rp, label="Vitesse M1")
#plt.plot(t_array_rp, refvelo1_list_rp, '--', label="Réf Vitesse M1")
plt.title("Vitesses")
plt.xlabel("Temps (s)")
plt.ylabel("Vitesse angulaire (rad/s)")
plt.legend()
plt.grid()

plt.figure()
plt.plot(t_array_rp, couple_mesure_rp, label="Couple Mesuré")
plt.title("Couple")
plt.xlabel("Temps (s)")
plt.ylabel("Couple mesuré en Nm")
plt.legend()
plt.grid()

plt.figure()
plt.plot(t_array_rp, cur0_rp, label="Courant M0")
plt.plot(t_array_rp, cur1_rp, label="Courant M1")
plt.title("Courants")
plt.xlabel("Temps (s)")
plt.ylabel("Courant mesuré (A)")
plt.legend()
plt.grid()

print(f"Cemmy1 = {np.mean(Ke*cur0_rp)}")

plt.figure()
plt.plot(t_array[mask_rp], tension0_calcule_rp, label="Tension M0 (calculée)")
plt.plot(t_array[mask_rp], tension1_calcule_rp, label="Tension M1 (calculée)")
plt.title("Tensions calculées")
plt.xlabel("Temps (s)")
plt.ylabel("Tention calculée (V)")
plt.legend()
plt.grid()

plt.figure()
plt.plot(cur0_rp, couple_mesure_rp, label="Caractéristique couple = f(I)")
plt.title("Caractéristique curant couple")
plt.legend()
plt.grid()

plt.figure()
plt.plot(t_array[mask_rp], puiss_elec0_rp, label="Puissance Électrique M0")
plt.plot(t_array[mask_rp], puiss_mec_rp, label="Puissance Mécanique")
plt.plot(t_array[mask_rp], puiss_elec1_rp, label="Puissance Électrique M1")
plt.title("Puissances")
plt.xlabel("Temps (s)")
plt.ylabel("Puissance (W)")
plt.legend()
plt.grid()

plt.figure()
plt.plot(vel0_rp, rendement0_rp, label="Rendement 1")
plt.plot(vel0_rp, rendement1_rp, label="Rendement 2")
plt.plot(vel0_rp, rendement_global_rp, label="Rendement Global")
plt.title("Rendement vs Vitesse (Régime Permanent)")
plt.xlabel("Vitesse (rad/s)")
plt.ylabel("Rendement (%)")
plt.legend()
plt.grid()

plt.tight_layout()
plt.show()

